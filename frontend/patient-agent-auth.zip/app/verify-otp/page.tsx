"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, ArrowLeft, Mail, RefreshCw } from "lucide-react"

export default function VerifyOTPPage() {
  const searchParams = useSearchParams()
  const email = searchParams.get("email") || ""
  const type = searchParams.get("type") || "registration"

  const [otp, setOtp] = useState(["", "", "", "", "", ""])
  const [isLoading, setIsLoading] = useState(false)
  const [isResending, setIsResending] = useState(false)
  const [timeLeft, setTimeLeft] = useState(60)
  const [canResend, setCanResend] = useState(false)
  const [error, setError] = useState("")

  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  // Timer for resend functionality
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else {
      setCanResend(true)
    }
  }, [timeLeft])

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return // Prevent multiple characters

    const newOtp = [...otp]
    newOtp[index] = value
    setOtp(newOtp)
    setError("")

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData("text").slice(0, 6)
    const newOtp = [...otp]

    for (let i = 0; i < pastedData.length && i < 6; i++) {
      if (/^\d$/.test(pastedData[i])) {
        newOtp[i] = pastedData[i]
      }
    }

    setOtp(newOtp)
    setError("")

    // Focus the next empty input or the last input
    const nextEmptyIndex = newOtp.findIndex((digit) => digit === "")
    if (nextEmptyIndex !== -1) {
      inputRefs.current[nextEmptyIndex]?.focus()
    } else {
      inputRefs.current[5]?.focus()
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const otpString = otp.join("")

    if (otpString.length !== 6) {
      setError("Please enter all 6 digits")
      return
    }

    setIsLoading(true)
    setError("")

    // Simulate OTP verification
    setTimeout(() => {
      setIsLoading(false)
      // For demo purposes, accept any 6-digit code
      if (otpString === "123456") {
        if (type === "registration") {
          window.location.href = "/login?verified=true"
        } else {
          window.location.href = `/reset-password?email=${encodeURIComponent(email)}&token=verified`
        }
      } else {
        setError("Invalid OTP. Please try again.")
        setOtp(["", "", "", "", "", ""])
        inputRefs.current[0]?.focus()
      }
    }, 2000)
  }

  const handleResend = async () => {
    setIsResending(true)
    setError("")

    // Simulate resending OTP
    setTimeout(() => {
      setIsResending(false)
      setTimeLeft(60)
      setCanResend(false)
      setOtp(["", "", "", "", "", ""])
      inputRefs.current[0]?.focus()
    }, 1000)
  }

  const getTitle = () => {
    return type === "registration" ? "Verify Your Email" : "Verify Your Identity"
  }

  const getDescription = () => {
    return type === "registration"
      ? "Enter the 6-digit code sent to your email to complete your registration"
      : "Enter the 6-digit code sent to your email to reset your password"
  }

  const getBackLink = () => {
    return type === "registration" ? "/register" : "/forgot-password"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-blue-600 p-2 rounded-full mr-2">
              <Heart className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Patient Agent</h1>
          </div>
          <p className="text-gray-600">Secure verification process</p>
        </div>

        <Card className="border-blue-100 shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 bg-blue-100 p-3 rounded-full w-fit">
              <Mail className="h-8 w-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl text-blue-900">{getTitle()}</CardTitle>
            <CardDescription className="text-center">{getDescription()}</CardDescription>
            <p className="text-sm text-gray-600 mt-2">
              Code sent to: <span className="font-medium text-gray-900">{email}</span>
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div className="flex justify-center space-x-2">
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      onPaste={handlePaste}
                      className="w-12 h-12 text-center text-xl font-bold border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 focus:outline-none transition-colors"
                      aria-label={`Digit ${index + 1}`}
                    />
                  ))}
                </div>

                {error && (
                  <div className="text-center text-sm text-red-600 bg-red-50 p-3 rounded-lg border border-red-200">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={isLoading || otp.join("").length !== 6}
                >
                  {isLoading ? "Verifying..." : "Verify Code"}
                </Button>
              </div>
            </form>

            <div className="text-center space-y-4">
              <div className="text-sm text-gray-600">{"Didn't receive the code?"}</div>

              {canResend ? (
                <Button
                  variant="outline"
                  onClick={handleResend}
                  disabled={isResending}
                  className="text-blue-600 border-blue-600 hover:bg-blue-50"
                >
                  {isResending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    "Resend Code"
                  )}
                </Button>
              ) : (
                <p className="text-sm text-gray-500">Resend code in {timeLeft}s</p>
              )}

              <div className="pt-4 border-t border-gray-200">
                <Link
                  href={getBackLink()}
                  className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800 hover:underline"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back to {type === "registration" ? "Registration" : "Forgot Password"}
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center text-xs text-gray-500 mt-6 space-y-1">
          <p>
            For demo purposes, use code: <span className="font-mono font-bold">123456</span>
          </p>
          <p>The verification code expires in 10 minutes</p>
        </div>
      </div>
    </div>
  )
}
